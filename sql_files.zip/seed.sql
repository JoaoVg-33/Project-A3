-- seed.sql
USE curadoria_db;

INSERT INTO roles (name, description) VALUES
  ('admin', 'Administrador do sistema'),
  ('user', 'Usuário padrão');

INSERT INTO users (username, email, password_hash, full_name, role_id) VALUES
  ('joao', 'joao@example.com', 'hash_senha_joao', 'João Silva', 1),
  ('maria', 'maria@example.com', 'hash_senha_maria', 'Maria Souza', 2);

INSERT INTO tags (name) VALUES
  ('java'),
  ('mysql'),
  ('design'),
  ('frontend');

INSERT INTO items (title, description, url, type, author_name, created_by) VALUES
  ('Guia MySQL para Iniciantes', 'Um guia completo para começar a usar MySQL', 'https://exemplo.com/mysql', 'article', 'João', 1),
  ('Padrões de Projeto em Java', 'Resumo sobre design patterns em Java', 'https://exemplo.com/java-patterns', 'article', 'Maria', 2),
  ('Introdução ao Frontend', 'Conceitos básicos de front-end web', 'https://exemplo.com/frontend', 'article', 'João', 1);

INSERT INTO item_tags (item_id, tag_id) VALUES
  (1, 2),
  (2, 1),
  (2, 3),
  (3, 4);

INSERT INTO curations (title, description, created_by, visibility) VALUES
  ('Artigos Java', 'Curadoria com os melhores artigos sobre Java', 1, 'public'),
  ('Tutoriais Web', 'Coleção de tutoriais para front‑end', 2, 'public');

INSERT INTO curation_items (curation_id, item_id, position, note) VALUES
  (1, 2, 1, 'Design patterns essenciais'),
  (2, 3, 1, 'Introdução ao desenvolvimento web');

INSERT INTO comments (item_id, user_id, content) VALUES
  (1, 2, 'Muito bom esse guia, me ajudou bastante!'),
  (2, 1, 'Ótimas explicações sobre padrões de projeto.');

INSERT INTO votes (item_id, user_id, value) VALUES
  (1, 2, +1),
  (2, 1, +1),
  (2, 2, -1);
